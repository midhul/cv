//hash function
	//function to hash pixel object
	var hash = function(pixel) {
		return String(pixel.x) + "," + String(pixel.y);
	}

	//function to unhash pixel object
	var unhash = function(pix, img) {
		var coords = pix.split(',').map(function(num) {return +num;});
		return img.pix[coords[0]][coords[1]];
	}

//floodfill algorithm
//Takes Image Data as arg
function floodFill(img, pixel, treshColor, treshSize) {


	//hashmap to keep track of processed pixels
	var done = new Object();

	//stack for floodfill
	var stack = new Array();

	//initialize other invariants
	var count = 0;
	stack.push(pixel);

	//start the floodfill process
	while(stack.length > 0) {
		var p = stack.pop();
		//check if pixel is to be processed
		if(!(!p || p.val > treshColor || done[hash(p)])) {
			count++; //increment count
			//push neighbours to stack
			var neighbours = img.neighbours(p);
			for(var i =0; i< neighbours.length; i++) {
				stack.push(neighbours[i]);
			}
			//mark as done
			done[hash(p)] = 1;
			//also mark as done in img object
			img.done[hash(p)] = 1;

		}

	}

	//check count 
	if(count <= treshSize) {
		//clear the pixels
		for(pix in done) {
			var p = unhash(pix, img); //get the pixel
			p.val = 255; //set to white

		}
		return 1;

	}

	else {
		return 0;
	}

}


$(document).ready(function() {
	var canvas = document.getElementById("myCanvas");
	var ctx = canvas.getContext("2d");

	//image width and height
	var cwidth = 252;
	var cheight = 65;



	//loading image onto canvas
	var image = new Image();
	//CHANGE IMAGE 
	image.src = "img/img10.png"; //change this to change image
	
	$(image).load(function() {
		ctx.drawImage(image, 0, 0);

		//get image data
		var imgData = ctx.getImageData(0, 0, cwidth, cheight);
		console.log(imgData.width);
		console.log(imgData.height);

		//initialize filters
		initFilters(imgData);

		//init pixel array
		imgData.pixRead();

		//floodfill noise removal
		//hashmap for recording done pixels
		imgData.done = new Object();
		for(var i=0; i< imgData.width; i++) {
			for(var j=0; j < imgData.height; j++) {
				var p = imgData.pix[i][j];
				if(!imgData.done[hash(p)]){
					floodFill(imgData, p, 240, 51);
					
				}

			}
		}

		//treshold to remove very light pixels
		imgData.treshold(240);

		//opening
		imgData.erode();
		imgData.dilate();
		imgData.dilate();
/**	imgData.erode();
		imgData.dilate();
	
		imgData.erode();
		imgData.dilate();
		imgData.erode();
		imgData.dilate();
		imgData.dilate(); **/


		//k-means clustering
		/**var clusters = kmeans(imgData, [{
			x: 28,
			y: 35
		}, {
			x: 70,
			y: 35
		}, {
			x: 130,
			y: 35
		}, {
			x: 175,
			y: 33
		}, {
			x: 225,
			y: 33
		}], 20);

		imgData.highlight(clusters[3]); **/  

		//whitespace segmentation
		whitespace(imgData, 0 ,0, 48800);
		
		
	
		



		//remember to load pixel data
		imgData.pixLoad();
		ctx.clearRect(0, 0, cwidth, cheight);
		ctx.putImageData(imgData, 0, 0);






	});
});