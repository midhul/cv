 //image width and height
    var cwidth = 252;
    var cheight = 65;


function getPixel(imgData, x, y, color) {
	var pixels = imgData.data;
	var width = imgData.width;

	var pos = ((y - 1) * (width * 4)) + ((x - 1) * 4) + color;
	return pixels[pos];

}

//remember to load image after setting pixels
function setPixel(imgData, x, y, color, val) {
	var pixels = imgData.data;
	var width = imgData.width;

	var pos = ((y - 1) * (width * 4)) + ((x - 1) * 4) + color;
	pixels[pos] = val;

}

//reload image onto canvas
function imgLoad(ctx, imgData) {
	ctx.clearRect(0, 0, cwidth, cheight);
	ctx.putImageData(imgData, 0, 0);
}

//invert filter
function invert(ctx, imgData) {
	var width = imgData.width;
	var height = imgData.height;

	for(var i=0; i<width; i++) {
		for(var j=0; j<height; j++) {
			setPixel(imgData, i, j, 0, 255 - getPixel(imgData, i ,j, 0)); // red
			setPixel(imgData, i, j, 1, 255 - getPixel(imgData, i ,j, 1)); // green
			setPixel(imgData, i, j, 2, 255 - getPixel(imgData, i ,j, 2)); // blue
		}
	}

	//reload image
	imgLoad(ctx, imgData);
}


//greyscale filter
function convert_grey(image_data){

  for (var x = 0; x < image_data.width; x++){
    for (var y = 0; y < image_data.height; y++){
      var i = x*4+y*4*image_data.width;
      var luma = Math.floor(image_data.data[i] * 299/1000 +
        image_data.data[i+1] * 587/1000 +
        image_data.data[i+2] * 114/1000);
 
      image_data.data[i] = luma;
      image_data.data[i+1] = luma;
      image_data.data[i+2] = luma;
      image_data.data[i+3] = 255;
    }
  }
}

//treshold filter
function treshold(ctx, imgData, theta) {
		var width = imgData.width;
	var height = imgData.height;
		for(var i=0; i<width; i++) {
		for(var j=0; j<height; j++) {
			if(getPixel(imgData, i, j, 0) > theta) {
				setPixel(imgData, i, j, 0, 255); // red
				setPixel(imgData, i, j, 1, 255); // green
				setPixel(imgData, i, j, 2, 255); // blue
			}
		}
	}

	//reload image
	imgLoad(ctx, imgData);
}

//check if given pixel is white
function isWhite(imgData, i ,j) {
	var val = getPixel(imgData, i, j, 0);
	return (val==255);

}

//filter to remove noise
function noiseRem(ctx, imgData, r) {
			var width = imgData.width;
	var height = imgData.height;
		for(var i=0; i<width; i++) {
		for(var j=0; j<height; j++) {
			//check around pixel
			var count = 0;
			for(var k=i-r; k<=i+r; k++) {
				if(getPixel(imgData,k,j-r,0) && getPixel(imgData,k,j-r,0)==255) count++;
			}
			for(var k=i-r; k<=i+r; k++) {
				if(getPixel(imgData,k,j+r,0) && getPixel(imgData,k,j+r,0)==255) count++;
			}
			for(var k=j-r+1; k<j+r; k++) {
				if(getPixel(imgData,i-r,k,0) && getPixel(imgData,i-r,k,0)==255) count++;
			}
			for(var k=j-r+1; k<j+r; k++) {
				if(getPixel(imgData,i+r,k,0) && getPixel(imgData,i+r,k,0)==255) count++;
			}

			if(count==8*r) {
				setPixel(imgData, i, j, 0, 255);
				setPixel(imgData, i, j, 1, 255);
				setPixel(imgData, i, j, 2, 255);
			}

		
			
		}
	}

	//reload image
	imgLoad(ctx, imgData);


}




$(document).ready(function() {
    var canvas = document.getElementById("myCanvas");
    var ctx = canvas.getContext("2d");

   

    //loading image onto canvas
    var image = new Image();
	image.src = "img/img3.png";
	$(image).load(function() {
	ctx.drawImage(image, 0, 0);

	//get image data
	var imgData = ctx.getImageData(0, 0, cwidth, cheight);
	console.log(imgData.width);
	console.log(imgData.height);


	convert_grey(imgData);
	imgLoad(ctx, imgData);
	treshold(ctx, imgData, 200);
	noiseRem(ctx, imgData, 1);
	noiseRem(ctx, imgData, 2);
	noiseRem(ctx, imgData, 3);
	noiseRem(ctx, imgData, 4);
	noiseRem(ctx, imgData, 1);
	noiseRem(ctx,imgData,5);
	noiseRem(ctx,imgData,6);
	noiseRem(ctx,imgData,7);
	noiseRem(ctx,imgData,8);
	noiseRem(ctx,imgData,9);
	noiseRem(ctx,imgData,10);
		noiseRem(ctx, imgData, 1);
	noiseRem(ctx, imgData, 2);
	noiseRem(ctx, imgData, 3);
	noiseRem(ctx, imgData, 4);
	noiseRem(ctx, imgData, 1);
	noiseRem(ctx,imgData,5);
	noiseRem(ctx,imgData,6);
	noiseRem(ctx,imgData,7);
	noiseRem(ctx,imgData,8);
	noiseRem(ctx,imgData,9);
	noiseRem(ctx,imgData,10);
		noiseRem(ctx, imgData, 1);
	noiseRem(ctx, imgData, 2);
	noiseRem(ctx, imgData, 3);
	noiseRem(ctx, imgData, 4);
	noiseRem(ctx, imgData, 1);
	noiseRem(ctx,imgData,5);
	noiseRem(ctx,imgData,6);
	noiseRem(ctx,imgData,7);
	noiseRem(ctx,imgData,8);
	noiseRem(ctx,imgData,9);
	noiseRem(ctx,imgData,10);
		noiseRem(ctx, imgData, 1);
	noiseRem(ctx, imgData, 2);
	noiseRem(ctx, imgData, 3);
	noiseRem(ctx, imgData, 4);
	noiseRem(ctx, imgData, 1);
	noiseRem(ctx,imgData,5);
	noiseRem(ctx,imgData,6);
	noiseRem(ctx,imgData,7);
	noiseRem(ctx,imgData,8);
	noiseRem(ctx,imgData,9);
	noiseRem(ctx,imgData,10);
	

	
	
 
});
});


