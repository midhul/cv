## README

* Extract the .zip file into a separate working directory.
* Open the page image.html using a web browser (preferably google chrome)
* You can modify the image number in the page.js file by going to the CHANGE IMAGE section
* img directory conatins a set of sample images