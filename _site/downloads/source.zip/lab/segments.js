/**
 * Scripts for segmetation or greyscale images
 *
 * (C) 2014 Midhul Varma
 */

//k-means clustering
function kmeans(img, centroids, times) {

	//start the clustering procedure
	for (var t = 0; t < times; t++) {
		//init clusters array
		var clusters = new Array();
		for (var i = 0; i < 5; i++) clusters[i] = new Array();

		//classify pixels
		for (var i = 0; i < img.width; i++) {
			for (var j = 0; j < img.height; j++) {
				//if not white pixel
				if (img.pix[i][j].val <= 240) {
					var pixel = img.pix[i][j];
					//find closest centroid
					var minDist = Infinity;
					var minPos = -1;
					for (var k = 0; k < centroids.length; k++) {
						var dist = (pixel.x - centroids[k].x) * (pixel.x - centroids[k].x) + (pixel.y - centroids[k].y) * (pixel.y - centroids[k].y);
						if (dist < minDist) {
							minDist = dist;
							minPos = k;
						}
					}

					//add to corresponding cluster
					clusters[minPos].push(pixel);

				}
			}
		}

		//find new centroids
		for (var i = 0; i < clusters.length; i++) {
			var N = clusters[i].length;
			var sigmax = 0;
			var sigmay = 0;
			for (var j = 0; j < N; j++) {
				sigmax += clusters[i][j].x;
				sigmay += clusters[i][j].y;
			}
			//update centroid
			centroids[i].x = sigmax / N;
			centroids[i].y = sigmay / N;

			console.log(centroids[i].x);
			console.log(centroids[i].y);
		}

		//check if last iteration
		if (t == times - 1) return clusters;


	}


}


//whitespace segmentation
function whitespace(img, minWidth, maxWidth, tresh) {
	for(var i=1; i< img.width-1; i++) {
		var sum = 0;
		for(var j = 0; j< img.height; j++) {
			sum += img.pix[i][j].val + img.pix[i-1][j].val + img.pix[i+1][j].val;
		}

		if(sum > tresh) {
			for(var j=0; j< img.height; j++) {
				img.pix[i][j].val = 0;
			}
		}
	}


}